package servlet;

class MyConstants {


    public static final String SITE_KEY ="6Lftix8UAAAAAPqxXLLzTr0MTbY4W08DFlKZXGC2";

    public static final String SECRET_KEY ="6Lftix8UAAAAANSKCWxBIxdWNe1j76d5mRzgcUo6";

}


